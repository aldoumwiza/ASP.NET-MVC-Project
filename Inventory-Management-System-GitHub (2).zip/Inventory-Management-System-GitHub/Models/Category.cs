﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace prjFinalDA3AldoUmwiza2.Models
{
    public class Category
    {
        private int categoryId;
        private string categoryName;
        private string description;

        public Category()
        {
        }

        public Category(int categoryId, string categoryName, string description)
        {
            this.CategoryId = categoryId;
            this.CategoryName = categoryName;
            this.Description = description;
        }

        public int CategoryId { get => categoryId; set => categoryId = value; }

        [Required]
        [StringLength(60)]
        public string CategoryName { get => categoryName; set => categoryName = value; }

        [StringLength(200)]
        public string Description { get => description; set => description = value; }
    }
}
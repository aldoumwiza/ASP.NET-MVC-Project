﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace prjFinalDA3AldoUmwiza2.Models
{
    public class Product
    {
        private int productId;
        private string productName;
        private int categoryId;
        private decimal purchasePrice;
        private decimal salePrice;
        private int quantity;
        private int minimumStock;
        private bool isActive;
        private string categoryName;

        public Product()
        {
        }

        public Product(int productId, string productName, int categoryId,
            decimal purchasePrice, decimal salePrice, int quantity,
            int minimumStock, bool isActive)
        {
            this.ProductId = productId;
            this.ProductName = productName;
            this.CategoryId = categoryId;
            this.PurchasePrice = purchasePrice;
            this.SalePrice = salePrice;
            this.Quantity = quantity;
            this.MinimumStock = minimumStock;
            this.IsActive = isActive;
        }

        public int ProductId { get => productId; set => productId = value; }

        [Required]
        [StringLength(100)]
        public string ProductName { get => productName; set => productName = value; }

        [Range(1, int.MaxValue)]
        public int CategoryId { get => categoryId; set => categoryId = value; }

        [Range(0.01, 99999999.99)]
        public decimal PurchasePrice { get => purchasePrice; set => purchasePrice = value; }

        [Required]
        public decimal SalePrice { get => salePrice; set => salePrice = value; }

        [Range(0, int.MaxValue)]
        public int Quantity { get => quantity; set => quantity = value; }

        [Range(0, int.MaxValue)]
        public int MinimumStock { get => minimumStock; set => minimumStock = value; }

        public bool IsActive { get => isActive; set => isActive = value; }

        public string CategoryName { get => categoryName; set => categoryName = value; }
    }
}
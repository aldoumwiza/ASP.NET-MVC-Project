﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using prjFinalDA3AldoUmwiza2.Data;
using prjFinalDA3AldoUmwiza2.Models;

namespace prjFinalDA3AldoUmwiza2.Controllers
{
    public class ProductController : Controller
    {
        ProductRepository repository = new ProductRepository();
        CategoryRepository categoryRepository = new CategoryRepository();

        //  all products
        public ActionResult Index(string keyword, int? categoryId)
        {
            try
            {
                var products = repository.Search(keyword, categoryId);

                ViewBag.Categories = new SelectList(
                    categoryRepository.GetAll(),
                    "CategoryId",
                    "CategoryName",
                    categoryId);

                ViewBag.Keyword = keyword;

                // inventory summary
                var allProducts = repository.GetAll();

                ViewBag.TotalProducts = allProducts.Count;
                ViewBag.TotalQuantity = allProducts.Sum(p => p.Quantity);
                ViewBag.TotalValue = allProducts.Sum(p => p.PurchasePrice * p.Quantity);

                return View(products);
            }
            catch (SqlException)
            {
                ViewBag.Error = "Database error.";

                ViewBag.Categories = new SelectList(
                    new List<Category>(),
                    "CategoryId",
                    "CategoryName");

                ViewBag.Keyword = keyword;
                ViewBag.TotalProducts = 0;
                ViewBag.TotalQuantity = 0;
                ViewBag.TotalValue = 0m;

                return View(new List<Product>());
            }
        }

        //  product details
        public ActionResult Details(int id)
        {
            try
            {
                Product product = repository.GetById(id);

                if (product == null)
                {
                    return HttpNotFound();
                }

                return View(product);
            }
            catch (SqlException)
            {
                return new HttpStatusCodeResult(500, "Database error.");
            }
        }

        // open create page
        public ActionResult Create()
        {
            try
            {
                ViewBag.Categories = new SelectList(
                    categoryRepository.GetAll(),
                    "CategoryId",
                    "CategoryName");

                return View();
            }
            catch (SqlException)
            {
                return new HttpStatusCodeResult(500, "Database error.");
            }
        }

        // save new product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (product.PurchasePrice <= 0)
            {
                ModelState.AddModelError(
                    "PurchasePrice",
                    "Purchase price must be greater than zero.");
            }

            if (product.SalePrice <= product.PurchasePrice)
            {
                ModelState.AddModelError(
                    "SalePrice",
                    "Sale price must be greater than purchase price.");
            }

            if (product.Quantity < 0)
            {
                ModelState.AddModelError(
                    "Quantity",
                    "Quantity cannot be negative.");
            }

            if (product.MinimumStock < 0)
            {
                ModelState.AddModelError(
                    "MinimumStock",
                    "Minimum stock cannot be negative.");
            }

            try
            {
                // check category
                if (categoryRepository.GetById(product.CategoryId) == null)
                {
                    ModelState.AddModelError(
                        "CategoryId",
                        "Please select an existing category.");
                }

                // check duplicate product
                var products = repository.GetAll();

                if (products.Any(p =>
                    p.CategoryId == product.CategoryId &&
                    string.Equals(
                        p.ProductName == null ? "" : p.ProductName.Trim(),
                        product.ProductName == null ? "" : product.ProductName.Trim(),
                        StringComparison.OrdinalIgnoreCase)))
                {
                    ModelState.AddModelError(
                        "ProductName",
                        "This product already exists in this category.");
                }

                if (ModelState.IsValid)
                {
                    repository.Add(product);

                    return RedirectToAction("Index");
                }
            }
            catch (SqlException)
            {
                ModelState.AddModelError(
                    "",
                    "Database error. Product was not saved.");
            }

            // reload categories if there is an error
            try
            {
                ViewBag.Categories = new SelectList(
                    categoryRepository.GetAll(),
                    "CategoryId",
                    "CategoryName",
                    product.CategoryId);
            }
            catch (SqlException)
            {
                ModelState.AddModelError("", "Cannot load categories.");

                ViewBag.Categories = new SelectList(
                    new List<Category>(),
                    "CategoryId",
                    "CategoryName");
            }

            return View(product);
        }

        // open edit page
        public ActionResult Edit(int id)
        {
            try
            {
                Product product = repository.GetById(id);

                if (product == null)
                {
                    return HttpNotFound();
                }

                ViewBag.Categories = new SelectList(
                    categoryRepository.GetAll(),
                    "CategoryId",
                    "CategoryName",
                    product.CategoryId);

                return View(product);
            }
            catch (SqlException)
            {
                return new HttpStatusCodeResult(500, "Database error.");
            }
        }

        // save edited product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            if (product.PurchasePrice <= 0)
            {
                ModelState.AddModelError(
                    "PurchasePrice",
                    "Purchase price must be greater than zero.");
            }

            if (product.SalePrice <= product.PurchasePrice)
            {
                ModelState.AddModelError(
                    "SalePrice",
                    "Sale price must be greater than purchase price.");
            }

            if (product.Quantity < 0)
            {
                ModelState.AddModelError(
                    "Quantity",
                    "Quantity cannot be negative.");
            }

            if (product.MinimumStock < 0)
            {
                ModelState.AddModelError(
                    "MinimumStock",
                    "Minimum stock cannot be negative.");
            }

            try
            {
                // check product
                if (repository.GetById(product.ProductId) == null)
                {
                    return HttpNotFound();
                }

                // check category
                if (categoryRepository.GetById(product.CategoryId) == null)
                {
                    ModelState.AddModelError(
                        "CategoryId",
                        "Please select an existing category.");
                }

                // check duplicate product
                var products = repository.GetAll();

                if (products.Any(p =>
                    p.CategoryId == product.CategoryId &&
                    p.ProductId != product.ProductId &&
                    string.Equals(
                        p.ProductName == null ? "" : p.ProductName.Trim(),
                        product.ProductName == null ? "" : product.ProductName.Trim(),
                        StringComparison.OrdinalIgnoreCase)))
                {
                    ModelState.AddModelError(
                        "ProductName",
                        "This product already exists in this category.");
                }

                if (ModelState.IsValid)
                {
                    repository.Update(product);

                    return RedirectToAction("Index");
                }
            }
            catch (SqlException)
            {
                ModelState.AddModelError(
                    "",
                    "Database error. Product was not updated.");
            }

            // reload categories when we gat an error
            try
            {
                ViewBag.Categories = new SelectList(
                    categoryRepository.GetAll(),
                    "CategoryId",
                    "CategoryName",
                    product.CategoryId);
            }
            catch (SqlException)
            {
                ModelState.AddModelError("", "Cannot load categories.");

                ViewBag.Categories = new SelectList(
                    new List<Category>(),
                    "CategoryId",
                    "CategoryName");
            }

            return View(product);
        }

        //  delete page
        public ActionResult Delete(int id)
        {
            try
            {
                Product product = repository.GetById(id);

                if (product == null)
                {
                    return HttpNotFound();
                }

                return View(product);
            }
            catch (SqlException)
            {
                return new HttpStatusCodeResult(500, "Database error.");
            }
        }

        // confirm delete
        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                if (repository.GetById(id) == null)
                {
                    return HttpNotFound();
                }

                repository.Delete(id);

                return RedirectToAction("Index");
            }
            catch (SqlException)
            {
                return new HttpStatusCodeResult(500, "Database error.");
            }
        }

        //  low stock products
        public ActionResult LowStock()
        {
            try
            {
                var products = repository.GetLowStockProducts();

                return View(products);
            }
            catch (SqlException)
            {
                ViewBag.Error = "Database error.";

                return View(new List<Product>());
            }
        }
    }
}
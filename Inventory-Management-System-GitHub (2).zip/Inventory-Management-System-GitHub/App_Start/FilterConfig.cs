﻿using System.Web;
using System.Web.Mvc;

namespace prjFinalDA3AldoUmwiza2
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}

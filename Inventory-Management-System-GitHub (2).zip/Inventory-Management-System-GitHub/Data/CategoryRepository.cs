﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using prjFinalDA3AldoUmwiza2.Models;

namespace prjFinalDA3AldoUmwiza2.Data
{
    public class CategoryRepository
    {
        DatabaseConnection db = new DatabaseConnection();

        // get all categories
        public List<Category> GetAll()
        {
            List<Category> categories = new List<Category>();

            using (SqlConnection con = db.GetConnection())
            {
                string query = "SELECT * FROM Categories";

                SqlCommand cmd = new SqlCommand(query, con);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Category category = new Category();

                        category.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        category.CategoryName = reader["CategoryName"].ToString();
                        category.Description = reader["Description"].ToString();

                        categories.Add(category);
                    }
                }
            }

            return categories;
        }

        // find category by id
        public Category GetById(int id)
        {
            Category category = null;

            using (SqlConnection con = db.GetConnection())
            {
                string query = "SELECT * FROM Categories WHERE CategoryId=@CategoryId";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@CategoryId", id);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        category = new Category();

                        category.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        category.CategoryName = reader["CategoryName"].ToString();
                        category.Description = reader["Description"].ToString();
                    }
                }
            }

            return category;
        }
    }
}
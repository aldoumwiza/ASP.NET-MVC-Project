﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using prjFinalDA3AldoUmwiza2.Models;

namespace prjFinalDA3AldoUmwiza2.Data
{
    public class ProductRepository
    {
        DatabaseConnection db = new DatabaseConnection();

        // get all products
        public List<Product> GetAll()
        {
            List<Product> products = new List<Product>();

            using (SqlConnection con = db.GetConnection())
            {
                string query = @"SELECT p.*, c.CategoryName
                                 FROM Products p
                                 INNER JOIN Categories c
                                 ON p.CategoryId = c.CategoryId";

                SqlCommand cmd = new SqlCommand(query, con);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Product product = new Product();

                        product.ProductId = Convert.ToInt32(reader["ProductId"]);
                        product.ProductName = reader["ProductName"].ToString();
                        product.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        product.PurchasePrice = Convert.ToDecimal(reader["PurchasePrice"]);
                        product.SalePrice = Convert.ToDecimal(reader["SalePrice"]);
                        product.Quantity = Convert.ToInt32(reader["Quantity"]);
                        product.MinimumStock = Convert.ToInt32(reader["MinimumStock"]);
                        product.IsActive = Convert.ToBoolean(reader["IsActive"]);
                        product.CategoryName = reader["CategoryName"].ToString();

                        products.Add(product);
                    }
                }
            }

            return products;
        }

        // find product by id
        public Product GetById(int id)
        {
            Product product = null;

            using (SqlConnection con = db.GetConnection())
            {
                string query = "SELECT * FROM Products WHERE ProductId=@ProductId";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ProductId", id);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        product = new Product();

                        product.ProductId = Convert.ToInt32(reader["ProductId"]);
                        product.ProductName = reader["ProductName"].ToString();
                        product.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        product.PurchasePrice = Convert.ToDecimal(reader["PurchasePrice"]);
                        product.SalePrice = Convert.ToDecimal(reader["SalePrice"]);
                        product.Quantity = Convert.ToInt32(reader["Quantity"]);
                        product.MinimumStock = Convert.ToInt32(reader["MinimumStock"]);
                        product.IsActive = Convert.ToBoolean(reader["IsActive"]);
                    }
                }
            }

            return product;
        }

        // add product
        public void Add(Product product)
        {
            using (SqlConnection con = db.GetConnection())
            {
                string query = @"INSERT INTO Products
                                (ProductName, CategoryId, PurchasePrice,
                                 SalePrice, Quantity, MinimumStock, IsActive)
                                VALUES
                                (@ProductName, @CategoryId, @PurchasePrice,
                                 @SalePrice, @Quantity, @MinimumStock, @IsActive)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.Parameters.AddWithValue("@PurchasePrice", product.PurchasePrice);
                cmd.Parameters.AddWithValue("@SalePrice", product.SalePrice);
                cmd.Parameters.AddWithValue("@Quantity", product.Quantity);
                cmd.Parameters.AddWithValue("@MinimumStock", product.MinimumStock);
                cmd.Parameters.AddWithValue("@IsActive", product.IsActive);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // update product
        public void Update(Product product)
        {
            using (SqlConnection con = db.GetConnection())
            {
                string query = @"UPDATE Products
                                 SET ProductName=@ProductName,
                                     CategoryId=@CategoryId,
                                     PurchasePrice=@PurchasePrice,
                                     SalePrice=@SalePrice,
                                     Quantity=@Quantity,
                                     MinimumStock=@MinimumStock,
                                     IsActive=@IsActive
                                 WHERE ProductId=@ProductId";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@ProductId", product.ProductId);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.Parameters.AddWithValue("@PurchasePrice", product.PurchasePrice);
                cmd.Parameters.AddWithValue("@SalePrice", product.SalePrice);
                cmd.Parameters.AddWithValue("@Quantity", product.Quantity);
                cmd.Parameters.AddWithValue("@MinimumStock", product.MinimumStock);
                cmd.Parameters.AddWithValue("@IsActive", product.IsActive);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // delete product
        public void Delete(int id)
        {
            using (SqlConnection con = db.GetConnection())
            {
                string query = "DELETE FROM Products WHERE ProductId=@ProductId";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ProductId", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // search products by name and category
        public List<Product> Search(string keyword, int? categoryId)
        {
            List<Product> products = new List<Product>();

            using (SqlConnection con = db.GetConnection())
            {
                string query = @"SELECT p.*, c.CategoryName
                                 FROM Products p
                                 INNER JOIN Categories c
                                 ON p.CategoryId = c.CategoryId
                                 WHERE (@keyword = '' OR p.ProductName LIKE @search)
                                 AND (@categoryId IS NULL OR p.CategoryId = @categoryId)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@keyword", keyword ?? "");
                cmd.Parameters.AddWithValue("@search", "%" + (keyword ?? "") + "%");
                cmd.Parameters.AddWithValue("@categoryId",
                    (object)categoryId ?? DBNull.Value);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Product product = new Product();

                        product.ProductId = Convert.ToInt32(reader["ProductId"]);
                        product.ProductName = reader["ProductName"].ToString();
                        product.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        product.PurchasePrice = Convert.ToDecimal(reader["PurchasePrice"]);
                        product.SalePrice = Convert.ToDecimal(reader["SalePrice"]);
                        product.Quantity = Convert.ToInt32(reader["Quantity"]);
                        product.MinimumStock = Convert.ToInt32(reader["MinimumStock"]);
                        product.IsActive = Convert.ToBoolean(reader["IsActive"]);
                        product.CategoryName = reader["CategoryName"].ToString();

                        products.Add(product);
                    }
                }
            }

            return products;
        }

        // get low stock products
        public List<Product> GetLowStockProducts()
        {
            List<Product> products = new List<Product>();

            using (SqlConnection con = db.GetConnection())
            {
                string query = @"SELECT p.*, c.CategoryName
                                 FROM Products p
                                 INNER JOIN Categories c
                                 ON p.CategoryId = c.CategoryId
                                 WHERE p.Quantity < p.MinimumStock";

                SqlCommand cmd = new SqlCommand(query, con);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Product product = new Product();

                        product.ProductId = Convert.ToInt32(reader["ProductId"]);
                        product.ProductName = reader["ProductName"].ToString();
                        product.CategoryId = Convert.ToInt32(reader["CategoryId"]);
                        product.PurchasePrice = Convert.ToDecimal(reader["PurchasePrice"]);
                        product.SalePrice = Convert.ToDecimal(reader["SalePrice"]);
                        product.Quantity = Convert.ToInt32(reader["Quantity"]);
                        product.MinimumStock = Convert.ToInt32(reader["MinimumStock"]);
                        product.IsActive = Convert.ToBoolean(reader["IsActive"]);
                        product.CategoryName = reader["CategoryName"].ToString();

                        products.Add(product);
                    }
                }
            }

            return products;
        }
    }
}
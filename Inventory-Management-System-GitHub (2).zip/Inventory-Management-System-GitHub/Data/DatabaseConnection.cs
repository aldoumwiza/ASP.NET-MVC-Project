﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace prjFinalDA3AldoUmwiza2.Data
{
    public class DatabaseConnection
    {
        public SqlConnection GetConnection()
        {
            string cs = ConfigurationManager.ConnectionStrings["InventoryConnection"].ConnectionString;

            return new SqlConnection(cs);
        }
    }
}